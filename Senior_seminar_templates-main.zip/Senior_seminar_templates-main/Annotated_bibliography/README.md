An example of using LaTeX and BibTeX to create an
annotated bibliography.

You don't have to use LaTeX to make your annotated 
bibliography for Senior Seminar, but it's a powerful
tool and gives you a chance to explore LaTeX early
instead of waiting until the last minute to begin
that part of the learning process.